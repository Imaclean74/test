The JavaScriptReact.tmLanguage bundle is derived from the TypeScriptReact.tmLanguage.

Changes:
- fileTypes -> .jsx
- scopeName -> scope.jsx

The JavaScript-ts.tmLanguage bundle is derived from the TypeScriptReact.tmLanguage.

Changes:
- all occurences of .ts -> .js
- fileTypes -> .js
- scopeName -> scope.js
