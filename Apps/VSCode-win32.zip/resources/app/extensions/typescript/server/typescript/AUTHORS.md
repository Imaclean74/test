TypeScript is authored by:

* Adam Freidin
* Ahmad Farid
* Anders Hejlsberg
* Arnav Singh
* Arthur Ozga
* Basarat Ali Syed
* Ben Duffield
* Bill Ticehurst
* Bryan Forbes
* Caitlin Potter
* Chris Bubernak
* Colby Russell
* Colin Snover
* Cyrus Najmabadi
* Dan Quirk
* Daniel Rosenwasser
* David Li
* Dick van den Brink
* Dirk B�umer
* Frank Wallis
* Gabriel Isenberg
* Gilad Peleg
* Guillaume Salles
* Harald Niesche
* Ingvar Stepanyan
* Ivo Gabe de Wolff
* James Whitney
* Jason Freeman
* Jason Ramsay
* Jed Mao
* Johannes Rieken
* Jonathan Bond-Caron
* Jonathan Park
* Jonathan Turner
* Josh Kalderimis
* Kagami Sascha Rosylight
* Keith Mashinter
* Kenji Imamula
* Lorant Pinter
* Masahiro Wakame
* Max Deepfield
* Micah Zoltu
* Mohamed Hegazy
* Oleg Mihailik
* Oleksandr Chekhovskyi
* Paul van Brenk
* Pedro Maltez
* Philip Bulley
* piloopin
* Ron Buckton
* Ryan Cavanaugh
* Sheetal Nandi
* Shengping Zhong
* Shyyko Serhiy
* Simon H�rlimann
* Solal Pirelli
* Stan Thomas
* Steve Lucco
* Tien Hoanhtien
* Tingan Ho
* togru
* Tomas Grubliauskas
* TruongSinh Tran-Nguyen
* Vladimir Matveev
* Wesley Wigham
* Yui Tanglertsampan
* Zev Spitz
* Zhengbo Li