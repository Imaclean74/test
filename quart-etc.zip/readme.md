#Readme

## Build commands

Shiv :

    shiv  -o quart-test.pyz . -r requirements.txt

Pex : 