from setuptools import setup, find_packages

setup(
    name='sample',
    version='0.1.0',
    description='Test Package',
    #long_description=readme,
    author='Ian MacLean',
    author_email='Ian.MacLean @gs.com',
    #url='https://github.com/kennethreitz/samplemod',
    #license=license,
    packages=find_packages(exclude=('tests', 'docs')),
     include_package_data=True, # to use manifest.in
    entry_points = {
        'console_scripts': ['app2=quart_test.app2:main'],
    }
)