from flask import Flask, Blueprint, jsonify, json
from flask_restplus import Resource, Api

import gevent
import gevent.monkey
gevent.monkey.patch_all()

from gevent.pywsgi import WSGIServer


@api.route('/hello_flask')
@api.doc("some function")
class CestralProto1(Resource):

    def get(self):
        return {'hello': 'world'}

## attr class for process, running component.

app = Flask(__name__)
api = Api(app)
app.debug = True

def background():
    print("my task")
    while true:
        print("my task")
        sleep(10)

def main():
    http_server = WSGIServer(('', 4430), app, keyfile='server.key', certfile='server.crt')
    srv_greenlet = gevent.spawn(http_server.start)
    background_task = gevent.spawn(background)
    try:
        gevent.joinall([srv_greenlet, background_task])
    except KeyboardInterrupt:
        print( "Exiting" )

if __name__ == '__main__':
    main()