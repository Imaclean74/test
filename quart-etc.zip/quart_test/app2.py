from flask import Flask, Blueprint, jsonify, json, render_template
from flask_restplus import Resource, Api
from webargs import fields
from typing import Dict, Tuple, List
from webargs.flaskparser import use_args

import logging.config
import socket
import pprint
import datetime

app = Flask(__name__)
api = Api(app)

#blueprint = Blueprint('api', __name__, url_prefix='/api')
#api = Api(blueprint, doc='/doc/') # defaults to /
#app.register_blueprint(blueprint)
# ##

# 
# @app.route('/<string:page_name>/')
# def render_static(page_name):
#     return render_template('%s.html' % page_name)

@app.route('/doc')
def welcome():
    return render_template('index.html')

def get_routes():
    func_list = {}
    for rule in app.url_map.iter_rules():
        if rule.endpoint != 'static':
            func_list[rule.rule] = app.view_functions[rule.endpoint].__doc__
    return func_list

@app.route('/api/help', methods = ['GET'])
def help():
    """Print available functions."""
    func_list = get_routes()
    return jsonify(func_list)

@api.route('/hello_flask<id>', endpoint='hello_flask')
#@api.doc(params={'id': 'Class-wide description'})
class CestralProto1(Resource):
    def __init__(self, api=None, *args, **kwargs ):
        Resource.__init__(self, api, args, kwargs )
        self.last = datetime.datetime.now() 
        self.components = Dict[str, str]

    @api.doc(params={'id': 'An ID'})
    def get(self, id : str):
        """Hello World Function."""
        if (  datetime.datetime.now() >  self.last + datetime.timedelta(minutes=2)  ):
            print("time to refresh our cache")
        return {'hello': 'world'}

def initialize_app(flask_app):
    pass

def main():

    initialize_app(app)
    print(
        '>>>>> Starting development server at http://{}/api/ <<<<<'.format(app.config['SERVER_NAME']))
    func_list = get_routes()
    pp = pprint.PrettyPrinter(indent=4)
    
    print( "Available routes are :" )
    pp.pprint(func_list)

    app.run(debug=True, host='0.0.0.0',port='5001' )

if __name__ == '__main__':
    main()