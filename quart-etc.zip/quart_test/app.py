from quart_openapi import Pint, Resource
import asyncio
from quart import render_template

app = Pint(__name__, title="Sample App")

async def background_task():
    
    print("my task")
    while true:
        print("my task")
        sleep(10)


@app.route('/doc')
def welcome():
    return render_template('index.html')

@app.route("/")
class Root(Resource):
    async def get(self):
        """Hello World Route

    This docstring will show up as the description and short-description
    for the openapi docs for this route.
    """
        return "hello"

def main():
    # Runs on another thread
    asyncio.run_in_executor(None, background_task())
    app.run()

if __name__ == '__main__':
    main()